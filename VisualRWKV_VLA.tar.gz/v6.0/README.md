# VisualRWKV: A Visual-Enhanced RWKV

## tl;dr
v6.0 update the model to use the RWKV-v6.0 language model.