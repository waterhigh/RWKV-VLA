# --- Example Test Script (test_policy_forward.py) ---
import os
os.environ["RWKV_JIT_ON"] = "1" # Enable RWKV JIT for potential speedup
os.environ["RWKV_HEAD_SIZE_A"] ="64"
os.environ["RWKV_CTXLEN"] = "256" # Set RWKV context length if needed

import torch
from argparse import Namespace # For creating dummy args objects
from visualrwkv_policy import VLMRWKV_DiffusionPolicy_ForwardTest

def rank_zero_info(msg):
    if not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0:
        print(msg)

# Assuming your modified VLMRWKV_DiffusionPolicy_ForwardTest is in visualrwkv_policy_simple.py
# And VisualRWKV (as nn.Module) is in src.model
# And ConditionalUnet1D is in policy_heads.models.droid_unet_diffusion

# from visualrwkv_policy_simple import VLMRWKV_DiffusionPolicy_ForwardTest
from src.model import VisualRWKV # Make sure this is the nn.Module version
from policy_heads.models.droid_unet_diffusion import ConditionalUnet1D


# 1. Define Arguments (replace with your actual configurations)
# VLM Args (ensure these match what your modified VisualRWKV (nn.Module) expects)
# VisualRWKV (nn.Module) should NOT have trainer-specific args like lr_init, betas, etc.
# but model structure args like n_layer, n_embd, ctx_len, vision_tower_name, etc.
vlm_args = Namespace(
    # Example RWKV args (must match your VisualRWKV internal RWKV model)
    n_layer=24,
    n_embd=2048,
    head_size_a = 64,
    dim_att=2048, # Example, adjust as needed
    ctx_len=256, # Example
    vocab_size=65536, # Example
    # head_qk_dim=0, # Add if your RWKV needs it
    # dim_ffn=0, # Add if your RWKV needs it, or rely on defaults
    dropout=0.0, # For inference, typically 0
    grad_cp=0,   # For inference, typically 0
    vision_tower_name="/root/zhihuieye/link2data/gyc_SV/VLA/weights/clip-vit-large-patch14-336/", # Or your ViT
    load_model="", # This is handled by vlm_checkpoint_path in the policy
    precision='fp16', # Or 'fp32', 'fp16'
    dim_ffn=int((2048 * 3.5)//32 * 32), # Example, adjust as needed
    # Add any other args your VisualRWKV class or its RWKV sub-module needs
    # For example, if RWKV has specific args for its layers:
    # my_pile_version=1, my_pos_emb=0, pre_ffn=0, head_size_divisor=8, ...
    # Basically, all args needed to construct RWKV(...) and VisualRWKV(...)
    # Ensure IGNORE_INDEX and IMAGE_TOKEN_INDEX are accessible or defined if needed by VLM
    ignore_index = -100, # Make sure this matches your VLM's actual ignore_index
    head_size_divisor=8, # Example, adjust as needed
    grid_size = 8, # Example for grid_pooling in VisualRWKV
)
# Define IMAGE_TOKEN_INDEX if VisualRWKV.preparing_embedding uses it globally
# Or ensure it's an attribute of vlm_args if VisualRWKV expects it there.
# For example:
# IMAGE_TOKEN_INDEX = -200 # Or whatever your VLM uses
# setattr(vlm_args, 'IMAGE_TOKEN_INDEX', IMAGE_TOKEN_INDEX) # If VisualRWKV accesses it via args


# Diffusion UNet Args (replace with your ConditionalUnet1D config)
diffusion_unet_args = {
    "down_dims": [64, 128, 256],
    "kernel_size": 5,
    "n_groups": 8,
    # Add other args for ConditionalUnet1D
}

# Policy Args
action_dim = 7
state_dim = 10 # Example, can be 0 if not used by your UNet
action_horizon = 16
vlm_checkpoint_path = "/root/zhihuieye/link2data/gyc_SV/VLA/weights/VisualRWKV-v060-1B6-v1.0-20240612.pth" # Actual path
# If VisualRWKV is already frozen or handles its freezing, these are not directly used by policy
# freeze_vlm = True
# num_vlm_layers_to_freeze = 0 

# Noise Scheduler Config
noise_scheduler_cfg = {
    "num_train_timesteps": 100, # For DDPMScheduler, used to derive betas
    "beta_schedule": 'squaredcos_cap_v2',
    "prediction_type": 'epsilon',
    "clip_sample": True,
    # "num_inference_timesteps": 20 # This is now a direct param to policy
}
num_inference_steps_for_policy = 20


# 2. Initialize the Simplified Policy Model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# IMPORTANT: Ensure VisualRWKV is modified to be nn.Module
# and doesn't rely on 'trainer' or pl.LightningModule features.
try:
    policy_model_test = VLMRWKV_DiffusionPolicy_ForwardTest(
        vlm_args=vlm_args,
        diffusion_unet_args=diffusion_unet_args,
        action_dim=action_dim,
        state_dim=state_dim,
        action_horizon=action_horizon,
        vlm_checkpoint_path=vlm_checkpoint_path,
        noise_scheduler_cfg=noise_scheduler_cfg,
        num_inference_steps=num_inference_steps_for_policy
    ).to(device)
    policy_model_test.eval() # Set to eval mode
except Exception as e:
    print(f"Error during policy model initialization: {e}")
    raise

# 3. Prepare Dummy Input Data
batch_size = 2
# VLM inputs
dummy_input_ids = torch.randint(0, vlm_args.vocab_size, (batch_size, 50), device=device) # seq_len = 50
# Example: insert an image token if your VLM expects it
# dummy_input_ids[:, 10] = IMAGE_TOKEN_INDEX # Assuming IMAGE_TOKEN_INDEX is defined
dummy_images = torch.randn(batch_size, 1, 3, 336, 336, device=device) # N_images=1
# Labels are often needed by preparing_embedding, fill with ignore_index
dummy_labels = torch.full_like(dummy_input_ids, vlm_args.ignore_index)

samples_for_vlm = {
    "input_ids": dummy_input_ids,
    "images": dummy_images,
    "labels": dummy_labels # VLM.preparing_embedding often needs this
}

# Robot states for diffusion head
dummy_robot_states = torch.randn(batch_size, state_dim, device=device)
if state_dim == 0: # Handle case where state_dim is 0
    dummy_robot_states = None


# 4. Perform a Forward Pass
rank_zero_info("--- Testing FORWARD Pass (Inference) ---")
try:
    with torch.no_grad(): # Ensure no gradients during inference test
        predicted_actions = policy_model_test(samples_for_vlm, dummy_robot_states)
    rank_zero_info(f"Predicted actions shape: {predicted_actions.shape}") # Expected: (B, action_horizon, action_dim)
    rank_zero_info(f"Predicted actions dtype: {predicted_actions.dtype}")
    rank_zero_info(f"Predicted actions device: {predicted_actions.device}")
    rank_zero_info(f"First predicted action sample: {predicted_actions[0, :2, :3]}") # Print a small part
    rank_zero_info("Forward pass completed successfully!")

except Exception as e:
    rank_zero_info(f"Error during forward pass: {e}")
    import traceback
    traceback.print_exc()

