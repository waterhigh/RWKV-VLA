import os, math, gc, importlib
os.environ["RWKV_JIT_ON"] = "1" # Enable RWKV JIT for potential speedup
os.environ["RWKV_HEAD_SIZE_A"] ="64"
os.environ["RWKV_CTXLEN"] = "256" # Set RWKV context length if needed

import torch
import torch.nn as nn
from torch.nn import functional as F
from transformers import CLIPVisionModel 
import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_info, rank_zero_only
from pytorch_lightning.strategies import DeepSpeedStrategy
from src.model import VisualRWKV 
from policy_heads.models.droid_unet_diffusion import ConditionalUnet1D

from diffusers import DDPMScheduler 

# --- Helper to print info nicely ---
def rank_zero_info(msg):
    if not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0:
        print(msg)

class VLMRWKV_DiffusionPolicy_ForwardTest(pl.LightningModule): # �̳��� nn.Module
    def __init__(self,
                 vlm_args,
                 diffusion_unet_args,
                 action_dim: int,
                 state_dim: int,
                 action_horizon: int,
                 vlm_checkpoint_path: str = None,
                 # freeze_vlm and num_vlm_layers_to_freeze are now handled within VisualRWKV if needed
                 noise_scheduler_cfg: dict = None,
                 # for inference
                 num_inference_steps: int = 20
                ):
        super().__init__()
        # Store some hyperparameters if needed for forward, though not strictly hparams anymore
        self.vlm_args = vlm_args
        self.diffusion_unet_args = diffusion_unet_args
        self.action_dim = action_dim
        self.state_dim = state_dim
        self.action_horizon = action_horizon
        self.num_inference_steps = num_inference_steps

        rank_zero_info("--- Initializing VLMRWKV_DiffusionPolicy (Forward Test Mode) ---")

        # 1. Initialize VisualRWKV
        # !!! IMPORTANT: VisualRWKV should now inherit from nn.Module, not pl.LightningModule !!!
        # And it should handle its own weight loading and potential freezing internally or via methods.
        self.vlm = VisualRWKV(vlm_args)
        rank_zero_info(f"VLM initialized. Initial dtype: {next(self.vlm.parameters()).dtype}")

        if vlm_checkpoint_path:
            rank_zero_info(f"Attempting to load VLM from checkpoint: {vlm_checkpoint_path}")
            try:
                # Assuming VisualRWKV has a method to load its state or
                # we load it directly here if it's just a state_dict for self.vlm
                checkpoint = torch.load(vlm_checkpoint_path, map_location='cpu')
                
                state_dict_to_load = checkpoint
                if 'state_dict' in checkpoint: # Common for Lightning checkpoints
                    # Check if 'state_dict' itself contains a 'vlm.' prefix or direct VisualRWKV keys
                    is_direct_vlm_keys_in_sd = any(k.startswith("rwkv.") or k.startswith("vit.") or k.startswith("proj.") for k in checkpoint['state_dict'].keys())
                    has_vlm_prefix_in_sd = any(k.startswith("vlm.") for k in checkpoint['state_dict'].keys())

                    if has_vlm_prefix_in_sd:
                        state_dict_to_load = {k.replace("vlm.", "", 1): v for k, v in checkpoint['state_dict'].items() if k.startswith("vlm.")}
                    elif is_direct_vlm_keys_in_sd: # If VisualRWKV was saved directly within a larger model's state_dict
                         state_dict_to_load = checkpoint['state_dict']
                    else: # Could be a checkpoint of VisualRWKV itself
                        state_dict_to_load = checkpoint['state_dict']

                elif any(k.startswith("rwkv.") or k.startswith("vit.") or k.startswith("proj.") for k in checkpoint.keys()):
                     # Checkpoint itself is likely a VisualRWKV state_dict
                     state_dict_to_load = checkpoint
                else:
                    rank_zero_info(f"Warning: Checkpoint format not recognized for VLM loading. Trying to load raw checkpoint.")
                    # Fallback or raise error
                
                if not state_dict_to_load:
                    rank_zero_info(f"Warning: Processed state_dict for VLM is empty. Check checkpoint format.")
                else:
                    missing_keys, unexpected_keys = self.vlm.load_state_dict(state_dict_to_load, strict=False)
                    rank_zero_info(f"Loaded VLM weights into self.vlm from {vlm_checkpoint_path}")
                    rank_zero_info(f"  VLM dtype after load_state_dict: {next(self.vlm.parameters()).dtype}")
                    if missing_keys:
                        rank_zero_info(f"  VLM Missing keys: {missing_keys[:5]}")
                    if unexpected_keys:
                        rank_zero_info(f"  VLM Unexpected keys: {unexpected_keys[:5]}")
            except Exception as e:
                rank_zero_info(f"Error loading VLM checkpoint {vlm_checkpoint_path} into self.vlm: {e}")
                rank_zero_info("VLM will continue with weights from initialization.")

        # Convert VLM to bfloat16 if CUDA kernel requires it (from vlm_args)
        # # This should ideally be part of VisualRWKV's setup or handled based on its args.
        # if hasattr(vlm_args, 'precision') and vlm_args.precision == 'bf16':
        #     if hasattr(torch, 'bfloat16'):
        #         if next(self.vlm.parameters()).dtype != torch.bfloat16:
        #             rank_zero_info(f"Converting VLM from {next(self.vlm.parameters()).dtype} to torch.bfloat16.")
        #             self.vlm = self.vlm.to(dtype=torch.bfloat16)
        #             rank_zero_info(f"VLM successfully converted to torch.bfloat16. New dtype: {next(self.vlm.parameters()).dtype}")
        #         else:
        #             rank_zero_info("VLM is already torch.bfloat16.")
        #     else:
        #         rank_zero_info("torch.bfloat16 not available. VLM dtype remains unchanged.")
        
        # Freeze VLM (example, adapt based on how VisualRWKV handles freezing)
        # self.vlm.requires_grad_(False) # Freeze all
        # if hasattr(self.vlm, 'freeze_rwkv'):
        #     self.vlm.freeze_rwkv(num_layers_to_freeze=getattr(vlm_args, 'num_rwkv_layers_to_freeze', 0))
        rank_zero_info(f"VLM is now in {next(self.vlm.parameters()).dtype}. Assuming frozen or handled by VisualRWKV's setup.")


        # 2. Initialize Diffusion Head
        self.diffusion_head = ConditionalUnet1D(
            input_dim=self.action_dim,
            global_cond_dim=self.vlm.args.n_embd, # Or vlm_args.n_embd
            state_dim=self.state_dim,
            **diffusion_unet_args
        )
        diffusion_params = sum(p.numel() for p in self.diffusion_head.parameters())
        rank_zero_info(f"Diffusion head initialized. Number of parameters: {diffusion_params / 1e6:.2f}M. Dtype: {next(self.diffusion_head.parameters()).dtype}")

        # 3. Initialize Noise Scheduler (only for inference structure)
        user_noise_scheduler_cfg = dict(noise_scheduler_cfg or {})
        # num_inference_steps used by DDPMScheduler.set_timesteps
        # user_noise_scheduler_cfg.pop("num_inference_timesteps", None) # already a param

        default_ddpm_cfg = {
            "num_train_timesteps": 1000, # Default for DDPMScheduler, not used for training here
            "beta_schedule": 'squaredcos_cap_v2',
            "prediction_type": 'epsilon', # or 'sample' or 'v_prediction'
            "clip_sample": True,
        }
        final_ddpm_cfg = {**default_ddpm_cfg, **user_noise_scheduler_cfg}
        rank_zero_info(f"Initializing DDPMScheduler with config: {final_ddpm_cfg}")
        try:
            self.noise_scheduler = DDPMScheduler(**final_ddpm_cfg)
        except TypeError as e:
            rank_zero_info(f"Error initializing DDPMScheduler: {e}. Check config keys.")
            raise e
        
        rank_zero_info("VLMRWKV_DiffusionPolicy (Forward Test Mode) initialized successfully.")


    def get_global_condition_from_vlm(self, samples_for_vlm):
        """
        Extracts the global_condition (hidden states before the final LM head)
        from the VisualRWKV model.
        """
        # Assumes VisualRWKV.preparing_embedding is a standard method call now
        # and VisualRWKV itself is a nn.Module
        try:
            x_vlm_embeds, _vlm_targets, _image_features = self.vlm.preparing_embedding(samples_for_vlm)
        except TypeError as e:
            rank_zero_info(f"TypeError during self.vlm.preparing_embedding: {e}")
            rank_zero_info("Check arguments for VisualRWKV.preparing_embedding or its internal calls.")
            raise e
        except Exception as e:
            rank_zero_info(f"Error during self.vlm.preparing_embedding: {e}")
            raise e

        x_for_rwkv = x_vlm_embeds
        # No dropout or grad_cp in eval mode by default in VisualRWKV's bidirectional_forward
        # We replicate the core logic for RWKV blocks and ln_out here for clarity
        
        # If VisualRWKV's dropout is nn.Dropout, it handles train/eval mode itself.
        # If it's custom, ensure it's off.
        # For grad_cp, it should only be active during training.

        for i, block in enumerate(self.vlm.rwkv.blocks):
            do_reverse = (i % 2 == 1)
            if do_reverse:
                # Ensure self.vlm.img_start and self.vlm.img_end are set correctly
                # by preparing_embedding or accessible otherwise.
                # This might need to be set as attributes on self.vlm by its methods.
                if not (hasattr(self.vlm, 'img_start') and hasattr(self.vlm, 'img_end')):
                    # Fallback if not set: try to infer or skip. For testing, this might be an issue.
                    # print("Warning: self.vlm.img_start/img_end not set, flip might be incorrect.")
                    pass # Or raise error if critical
                else:
                    x_for_rwkv[:, self.vlm.img_start:self.vlm.img_end, :] = \
                        x_for_rwkv[:, self.vlm.img_start:self.vlm.img_end, :].flip(dims=[1])
            
            x_for_rwkv = block(x_for_rwkv) # No grad_cp in eval
            
            if do_reverse:
                if not (hasattr(self.vlm, 'img_start') and hasattr(self.vlm, 'img_end')):
                    pass
                else:
                    x_for_rwkv[:, self.vlm.img_start:self.vlm.img_end, :] = \
                        x_for_rwkv[:, self.vlm.img_start:self.vlm.img_end, :].flip(dims=[1])

        global_condition = self.vlm.rwkv.ln_out(x_for_rwkv)
        # For this test, we don't need VLM logits or targets for a loss.
        return global_condition


    @torch.no_grad() # Ensure no gradients for inference
    def forward(self, samples_for_vlm, robot_states):
        """
        Performs a single forward pass for inference (action generation).
        Args:
            samples_for_vlm (dict): Inputs for VisualRWKV, e.g., {"input_ids": ..., "images": ...}
                                    (labels are not strictly needed for inference by VLM).
            robot_states (torch.Tensor): (B, StateDim) or (B, 1, StateDim)
        Returns:
            torch.Tensor: Predicted actions (B, ActionHorizon, ActionDim)
        """
        self.eval() # Set model to evaluation mode

        if robot_states.ndim == 3 and robot_states.shape[1] == 1:
             robot_states = robot_states.squeeze(1)
        
        # 1. Get global_condition from VLM
        # samples_for_vlm might need dummy labels if preparing_embedding expects them
        if "labels" not in samples_for_vlm and hasattr(self.vlm, 'args') and hasattr(self.vlm.args, 'ignore_index'):
            dummy_labels = torch.full_like(samples_for_vlm["input_ids"], self.vlm.args.ignore_index)
            samples_for_vlm_with_labels = {**samples_for_vlm, "labels": dummy_labels}
        else:
            samples_for_vlm_with_labels = samples_for_vlm

        global_condition_seq = self.get_global_condition_from_vlm(samples_for_vlm_with_labels)
        # global_condition_seq: (B, SeqLen_vlm, n_embd)

        # --- Select how to get global_condition_for_unet from global_condition_seq ---
        # Option A: UNet handles sequence (e.g. via cross-attention)
        global_condition_for_unet = global_condition_seq
        # Option B: Use last token's features (make sure it's meaningful, e.g., after text)
        # global_condition_for_unet = global_condition_seq[:, -1, :] 
        # Option C: Mean pool
        # global_condition_for_unet = torch.mean(global_condition_seq, dim=1)
        # rank_zero_info(f"Shape of global_condition for UNet: {global_condition_for_unet.shape}")


        # 2. Diffusion process for action generation
        batch_size = global_condition_for_unet.size(0)
        shape = (batch_size, self.action_horizon, self.action_dim)
        
        # Initialize action from Gaussian noise
        # Ensure dtype matches diffusion_head's expected input, typically float32
        pred_actions_noisy = torch.randn(shape, device=global_condition_for_unet.device, dtype=torch.float32)
        
        self.noise_scheduler.set_timesteps(self.num_inference_steps)

        for k_t in self.noise_scheduler.timesteps:
            timestep_input = k_t.to(global_condition_for_unet.device)
            if batch_size > 1 and timestep_input.ndim == 0:
                timestep_input = timestep_input.repeat(batch_size)

            # Ensure inputs to diffusion_head have consistent dtypes (usually float32)
            # global_condition_for_unet might be bf16 if VLM is bf16.
            # ConditionalUnet1D might expect float32.
            current_global_cond = global_condition_for_unet.to(torch.float32)
            current_robot_states = robot_states.to(torch.float32) if robot_states is not None else None

            noise_pred_step = self.diffusion_head(
                sample=pred_actions_noisy.to(torch.float32), # Ensure sample is float32
                timestep=timestep_input,
                global_cond=current_global_cond,
                states=current_robot_states
            )
            
            # Scheduler step
            scheduler_output = self.noise_scheduler.step(
                model_output=noise_pred_step.to(torch.float32), # Ensure model_output is float32
                timestep=k_t, # scheduler step might expect scalar
                sample=pred_actions_noisy.to(torch.float32) # Ensure sample is float32
            )
            pred_actions_noisy = scheduler_output.prev_sample
            
        return pred_actions_noisy.to(global_condition_for_unet.dtype) # Cast back if needed, or keep as float32
