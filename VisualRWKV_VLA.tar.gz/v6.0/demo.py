import os
os.environ["RWKV_JIT_ON"] = "1" # Enable RWKV JIT for potential speedup

import json
from PIL import Image
import numpy as np
import math
import argparse
import torch
from pathlib import Path

# Assuming src.rwkv_tokenizer, src.dataset, src.utils are in the same directory or PYTHONPATH
# If your tokenizer is in a different location, adjust the import
try:
    # Attempt to import tokenizer from a 'src' directory
    from src.rwkv_tokenizer import TRIE_TOKENIZER 
except ImportError:
    # Fallback if the tokenizer might be in a different common location or needs path adjustment
    # from tokenizer import TRIE_TOKENIZER 
    raise ImportError("Please ensure TRIE_TOKENIZER is available from src.rwkv_tokenizer or adjust the import path.")

# Import constants and utility functions for dataset processing
from src.dataset import DEFAULT_IMAGE_TOKEN, DEFAULT_STOP_TOKEN, STOP_TOKEN_INDEX
from src.dataset import process_image_tokens_in_conversations, preprocess
from src.utils import Conversation, gpt4v_crop # load_image_from_base64 might not be needed for local demo

# For CLIP-based VisualRWKV, we'll use CLIPImageProcessor from Hugging Face transformers
from transformers import CLIPImageProcessor

def get_single_image_tensor_clip(image_path: str, image_processor: CLIPImageProcessor, detail: str = 'low'):
    """
    Loads a single image, processes it using CLIPImageProcessor.
    Handles 'low' and 'high' detail similar to the eval script.
    
    Args:
        image_path (str): Path to the image file.
        image_processor (CLIPImageProcessor): Initialized CLIP image processor.
        detail (str): 'low' or 'high'. 'high' uses gpt4v_crop for more image patches.
        
    Returns:
        torch.Tensor or None: Processed image tensor or None if an error occurs.
    """
    try:
        image = Image.open(image_path).convert("RGB") # Open and convert image to RGB
    except FileNotFoundError:
        print(f"Error: Image file not found at {image_path}")
        return None
    except Exception as e:
        print(f"Error opening image {image_path}: {e}")
        return None

    if detail == 'high':
        # For high detail, process the original image and additional crops from gpt4v_crop
        try:
            images_to_process = [image] + gpt4v_crop(image) # Create a list of images (original + crops)
            pixel_values_list = []
            for img_idx, img in enumerate(images_to_process):
                # Process each image/crop using the CLIP image processor
                processed = image_processor(images=img, return_tensors='pt')
                pixel_values_list.append(processed['pixel_values'])
            # Concatenate the tensors from all images/crops along the batch dimension (dim=0)
            image_tensor = torch.cat(pixel_values_list, dim=0) 
        except Exception as e:
            print(f"Error processing high detail image {image_path}: {e}")
            # Fallback to low detail processing if high detail fails
            try:
                print("Falling back to low detail processing for high detail error.")
                image_tensor = image_processor(images=image, return_tensors='pt')['pixel_values']
            except Exception as e_low:
                print(f"Error processing low detail image after high detail fallback: {e_low}")
                return None
    else: # low detail
        try:
            # Process the single image with the CLIP image processor
            image_tensor = image_processor(images=image, return_tensors='pt')['pixel_values']
        except Exception as e:
            print(f"Error processing low detail image {image_path}: {e}")
            return None
            
    return image_tensor


def interactive_demo(args):
    """
    Main function to run the interactive demo.
    """
    # Dynamically import VisualRWKV model class from src.model
    # This ensures that any specific setup within VisualRWKV for CLIP is used
    from src.model import VisualRWKV # Ensure this VisualRWKV is compatible with CLIP
    
    print("Initializing model...") # Chinese: 
    model_path = Path(args.model_path) # Convert model_path string to a Path object

    # --- Model Initialization ---
    # The VisualRWKV class (CLIP version) is expected to use args.vision_tower_name 
    # for the CLIP model path and potentially args.grid_size for visual feature handling.
    model = VisualRWKV(args) # Instantiate the VisualRWKV model
    
    try:
        print(f"Loading model weights from...{model_path}") # Chinese: Loading model weights from...
        # Load the model state dictionary. 
        # `strict=False` allows for some flexibility if not all keys match perfectly,
        # which can be common when combining pre-trained parts.
        msg = model.load_state_dict(torch.load(model_path, map_location='cpu'), strict=False)
        print("Message from loading model weights: ", msg) # Chinese: Message from loading model weights...
        # Check if there were missing or unexpected keys during loading
        if hasattr(msg, 'missing_keys') and msg.missing_keys:
             print(f"Warning: Missing keys during model loading: {msg.missing_keys}") # Chinese: Warning: Missing keys...
        if hasattr(msg, 'unexpected_keys') and msg.unexpected_keys:
             print(f"Warning: Unexpected keys during model loading: {msg.unexpected_keys}") # Chinese: Warning: Unexpected keys...
    except Exception as e:
        print(f"Error loading model weights: {e}") # Chinese: Error loading model weights...
        return

    # Convert model to bfloat16 for mixed-precision inference (if supported and desired)
    # and move it to the specified device (e.g., "cuda" or "cpu")
    model = model.bfloat16().to(args.device)
    model.eval() # Set the model to evaluation mode (disables dropout, etc.)

    # --- Tokenizer and Image Processor ---
    try:
        # Initialize the RWKV tokenizer
        tokenizer = TRIE_TOKENIZER(args.tokenizer_path) # Use tokenizer_path from args
    except Exception as e:
        print(f"Error loading tokenizer: {e}. Please ensure '{args.tokenizer_path}' exists.") # Chinese: Error loading tokenizer...
        return
        
    try:
        # args.vision_tower_name should be a Hugging Face model identifier (e.g., "openai/clip-vit-large-patch14-336")
        # or a local path to a CLIP model.
        print(f"Loading CLIPImageProcessor from: {args.vision_tower_name}") # Chinese: Loading CLIPImageProcessor from...
        image_processor = CLIPImageProcessor.from_pretrained(args.vision_tower_name)
    except Exception as e:
        print(f"Error loading CLIPImageProcessor from '{args.vision_tower_name}': {e}") # Chinese: Error loading CLIPImageProcessor...
        return

    print("Model (CLIP version) and tokenizer initialized.")
    print("Interactive demo started. Type 'quit' or an image path to exit.") # Chinese: Interactive demo started...

    while True:
        try:
            image_path_input = input("Enter image path...").strip() # Chinese: Enter image path...
            if image_path_input.lower() == 'quit':
                break

            user_prompt_input = input(f"Please enter your question (image token {DEFAULT_IMAGE_TOKEN} will be automatically added at the beginning): ").strip() # Chinese: Your prompt...
            if user_prompt_input.lower() == 'quit':
                break

            if not image_path_input or not Path(image_path_input).is_file():
                print(f"Image path '{image_path_input}' is invalid or the file does not exist. Please try again.") # Chinese: Image path invalid...
                continue
            if not user_prompt_input:
                print("Prompt cannot be empty. Please try again.") # Chinese: Prompt cannot be empty...
                continue

            print("Processing image...") # Chinese: Processing image...
            # Process the single image using the CLIP processor
            image_tensor = get_single_image_tensor_clip(image_path_input, image_processor, args.detail)
            if image_tensor is None: # If image processing failed
                continue
            
            # Move the processed image tensor to the specified device and convert to bfloat16
            image_tensor = image_tensor.bfloat16().to(args.device)

            # --- Prepare inputs for VisualRWKV ---
            # The input text format depends on how your model was trained.
            # Typically, it's <IMAGE_TOKEN> followed by a newline and the user's prompt.
            input_text = DEFAULT_IMAGE_TOKEN + "" + user_prompt_input

            # Create a Conversation object to structure the input
            conv = Conversation(id="interactive_session", roles=["human", "gpt"], conversations=[])
            conv.append_message(conv.roles[0], input_text) # Add human message
            conv.append_message(conv.roles[1], "") # Add an empty assistant message slot for generation

            # process_image_tokens_in_conversations replaces image placeholders with actual image tokens 
            # or handles their positioning based on `image_position`.
            # `num_image_paths=1` indicates one conceptual image is being processed.
            conversations_processed = process_image_tokens_in_conversations(
                conv.conversations,
                image_position=args.image_position 
            )
            
            
            # Preprocess the conversation to get model inputs (input_ids, labels, etc.)
            data_dict = preprocess(
                conversations_processed,
                tokenizer,
                has_image=True, # Indicate that there is an image
                ctx_len=args.ctx_len, # Context length for RWKV
                pad_token_id=tokenizer.pad_token_id if hasattr(tokenizer, 'pad_token_id') and tokenizer.pad_token_id is not None else 0, # Pad token ID (0 for RWKV)
                do_pad_to_max_length=False # Typically False for generation
            )

            # Get input_ids from the preprocessed data, add a batch dimension, and move to device
            input_ids = data_dict['input_ids'].unsqueeze(0).to(args.device)

            print("Generating response...") # Chinese: Generating response...
            with torch.inference_mode(): # Disable gradient calculations for inference
                # The `images` argument for `model.generate` typically expects a batch of image tensors.
                # If image_tensor from get_single_image_tensor_clip is [num_crops, C, H, W],
                # we add a batch dimension to make it [1, num_crops, C, H, W].
                output_ids, _, _ = model.generate( 
                    input_ids,
                    images=image_tensor.unsqueeze(0), # Add batch dimension for the image tensor
                    do_sample=False, # Enable sampling if temperature is set
                    temperature=args.temperature, # Temperature for sampling
                    top_p=args.top_p, # Top-p (nucleus) sampling parameter
                    max_new_tokens=args.max_new_tokens, # Maximum number of new tokens to generate
                    stop_token_idx=STOP_TOKEN_INDEX # Token ID to stop generation
                )
            generated_tokens_list = output_ids

            if generated_tokens_list: # Check if any tokens were generated
                output_text = tokenizer.decode(generated_tokens_list) 
                # Remove the stop token and any trailing whitespace (like in evaluate.py)
                output_text = output_text.split(DEFAULT_STOP_TOKEN)[0].strip()
                print(f"Model Response: {output_text}")
            else:
                print("Model Response: (No tokens generated)")
            
            torch.cuda.empty_cache()

        except KeyboardInterrupt:
            print("Exiting demo...") # Chinese: Exiting demo...
            break
        except Exception as e:
            print(f"An error occurred: {e}") # Chinese: An error occurred...
            import traceback
            traceback.print_exc() # Print detailed traceback for debugging

    print("Interactive demo finished.") # Chinese: Interactive demo finished.


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Interactive Demo for CLIP-based VisualRWKV Model")
    
    # --- RWKV specific arguments (similar to those in eval_model.py) ---
    # These define the architecture of the RWKV language model part.
    #parser.add_argument("--load_model", default="", type=str, help="Path to the initial RWKV base model (e.g., RWKV-x060-World-1B6.pth) if your VisualRWKV checkpoint only contains visual parts and projector. Not always needed if VisualRWKV checkpoint is self-contained.")
    parser.add_argument("--load_model", default="", type=str, help="Path to the initial RWKV base model (e.g., RWKV-x060-World-1B6.pth) if your VisualRWKV checkpoint only contains visual parts and projector. Not always needed if VisualRWKV checkpoint is self-contained.")
    parser.add_argument("--vocab_size", default=65536, type=int, help="Vocabulary size of the RWKV model.")
    parser.add_argument("--ctx_len", default=256, type=int, help="Context length for the RWKV model.")
    parser.add_argument("--n_layer", default=32, type=int, help="Number of layers in the RWKV model.")
    parser.add_argument("--n_embd", default=2560, type=int, help="Embedding dimension of the RWKV model.")
    parser.add_argument("--dim_att", default=0, type=int, help="Attention dimension (if different from n_embd). Set to 0 to use n_embd.")
    parser.add_argument("--dim_ffn", default=0, type=int, help="Feed-forward network dimension. Set to 0 for default calculation.")
    parser.add_argument("--pre_ffn", default=0, type=int, help="Replace the first attention layer with an FFN layer if > 0.")
    parser.add_argument("--head_size_a", default=64, type=int, help="Head size for RWKV attention mechanism.")
    parser.add_argument("--head_size_divisor", default=8, type=int, help="Divisor for head size calculation.")
    parser.add_argument("--dropout", default=0.0, type=float, help="Dropout rate (usually 0 for inference).")
    parser.add_argument("--grad_cp", default=0, type=int, help="Enable gradient checkpointing if > 0 (saves VRAM but slower, for training).")
    # ...
    # --- VisualRWKV (CLIP version) specific arguments ---
    parser.add_argument("--vision_tower_name", default="/root/zhihuieye/link2data/gyc_SV/VLA/weights/clip-vit-large-patch14-336/", type=str, help="CLIP model name from Hugging Face or local path (e.g., openai/clip-vit-base-patch32, openai/clip-vit-large-patch14-336). This is used to load the CLIPImageProcessor and potentially the vision tower within VisualRWKV if not loaded from model_path.")
    parser.add_argument("--grid_size", type=int, default=-1, help="Grid size for processing visual features from CLIP. Interpretation depends on VisualRWKV implementation: -1 for auto/default, 0 for CLS token only, >0 for specific grid (e.g., 16 for 16x16=256 tokens).")
    parser.add_argument("--detail", type=str, default="low", choices=['low', 'high'], help="Image detail level for processing ('low' or 'high' for gpt4v_crop). 'high' might generate more patches from the image.")
    parser.add_argument("--image_position", default='middle', type=str, choices=['first', 'last', 'middle'], help="Position of the image token(s) relative to text in the input sequence (e.g., <image>text or text<image>).")
    parser.add_argument("--tokenizer_path", type=str, default="src/rwkv_vocab_v20230424.txt", help="Path to the RWKV tokenizer vocabulary file.")


    # --- Demo specific arguments ---
    parser.add_argument("--model_path", type=str, default="/root/zhihuieye/link2data/gyc_SV/VLA/weights/VisualRWKV-v060-3B-v1.0-20240612.pth", help="Path to the VisualRWKV (CLIP version) model checkpoint (.pth file). This checkpoint should contain weights for the RWKV LM, the vision projector, and potentially the vision tower if it's fine-tuned.")
    parser.add_argument("--temperature", type=float, default=0.2, help="Sampling temperature for generation. Higher values make output more random. 0 means greedy decoding if do_sample is False.")
    parser.add_argument("--top_p", type=float, default=0.8, help="Nucleus sampling parameter. Considers tokens with cumulative probability up to top_p. Set to None or 1.0 to disable.")
    parser.add_argument("--max_new_tokens", type=int, default=128, help="Maximum number of new tokens to generate in the response.")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu", help="Device to run the model on ('cuda' or 'cpu').")

    args = parser.parse_args()

    # --- Environment variable setup (can be important for RWKV internal workings) ---
    os.environ["RWKV_HEAD_SIZE_A"] = str(args.head_size_a)
    # RWKV_CTXLEN is not directly used by RWKV v5/v6 model's forward pass for its state,
    # but some scripts or utilities might still refer to it. args.ctx_len is used in preprocessing.
    os.environ["RWKV_CTXLEN"] = str(args.ctx_len) 
    
    # --- Derive or set default RWKV architectural parameters if not fully specified ---
    if args.dim_att <= 0:
        args.dim_att = args.n_embd # Default attention dimension to embedding dimension
    if args.dim_ffn <= 0:
        # Default FFN dimension calculation. This can vary between RWKV versions.
        # The eval script used 3.5x n_embd. This is common for some RWKV-4/5 variants.
        # RWKV-x060 (v6) often has a different FFN dim calculation, e.g., n_embd * (7/4*4/3) / 32 * 32 or simply 2*n_embd.
        # Using 3.5x as per the provided eval script. Adjust if your model (e.g., v6 based) uses a different FFN size.
        args.dim_ffn = int((args.n_embd * 3.5) // 32 * 32) 
        print(f"Note: --dim_ffn not set, defaulted to {args.dim_ffn} (3.5 * n_embd, rounded). Adjust if your model uses a different FFN size.")

    interactive_demo(args)
